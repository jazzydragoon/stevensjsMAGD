
//Make the owls into retro zelda-ish hearts!

let x = 10

function setup() {

	createCanvas(480, 400);
}

function draw() {

	background(204);

	// using a for loop, owl function is called until the x position is less than the width of the sketch plus 70 pixels
    
	for (var x = 1; x < width + 120; x += 150) {
		retroHeart(x, 10);
      fill(255, 55, 55, 255);
	}
}

function retroHeart(x, y) {

	push(); // create a new drawing state

    angleMode(DEGREES);
  
	translate(x, y);
    rotate(PI / 3.0);
  noStroke();
  square(75, 75, 25);
  square(100, 100, 25);
  scale(0.75);
  square(125, 75, 25);
  square(75, 100, 25);
  square(125, 100, 25);
  square(50, 100, 25);
  square(150, 100, 25);
  square(100, 125, 25);
  square(75, 125, 25);
  scale(0.95);
  square(125, 125, 25);
  square(100, 150, 25);

	pop(); // return the drawing state to it's original state, before the push() function

  
  print('The value of x is ' + x);
  
}