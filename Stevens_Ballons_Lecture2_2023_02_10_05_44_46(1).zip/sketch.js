function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  quad(88, 81, 106, 90, 109, 103, 107, 116);
  noFill();
  curve(70, 42, 100, 143, 170, 174, 280, 385);
  fill(0,0,255,160);
  ellipse(100, 100, 50, 65);
  triangle(100,130,95,145,105,145);
  fill(255,0,0,160);
  ellipse(200, 200, 50, 65);
  triangle(200,230,195,245,205,245);
  fill(0,255,0,160);
  ellipse(225, 225, 25, 35);
  triangle(225,240,215,255,230,255);
  fill(255,233,0, 160);
    ellipse(300, 300, 50, 65);
  triangle(300,330,295,345,305,345);
  fill(255,255,255);
}
