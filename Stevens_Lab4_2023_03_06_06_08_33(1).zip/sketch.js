
let y = 0;
let num = 14;
var x = 215;

function setup() {
  createCanvas(400, 400);
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  rect(25, 25, 50, 50);
  stroke(0); 
  frameRate(30);
  translate(width / 2, height / 2);
  rotate(PI / 3.0);
  rect(-26, -26, 52, 52);  
  }
}

function draw() {

  background(0); // Set the background to black
  y = y - 1;
  if (y < 0) {
    y = height;
  }
  line(0, y, width, y);
}

let value = 0;
function draw() {
  fill(value);
  rect(25, 25, 50, 50);
}

function mouseClicked() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
 
  if (keyIsPressed) {
    if (keyCode == LEFT_ARROW) {
      x--;
    }
    else if (keyCode == RIGHT_ARROW) {
      x++;
    }
  }
  rect(x, 45, 50, 50);
  
  y = 45;
  fill(145);
  for (let i = 0; i < num - 1; i++) {
    rect(120, y, 40, 1);
    y += 20;
  }
  
}